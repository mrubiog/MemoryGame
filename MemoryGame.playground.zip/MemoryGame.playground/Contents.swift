//: Playground - noun: a place where people can play

import UIKit

var datos = 0...100                     //rango de datos del 0 al 100

for i in datos {
    switch i{
    case i where i % 5 == 0 :
        print("\(i) Bingo!!!")          //el número asignado es divisible por 5
    case i where i % 2 == 0 :
        print("\(i) par!!!")            //el número asignado es par
    case i where i >= 30 && i <= 40 :
        print ("\(i) Viva Swift!!!")    // el número asignado se encuentra en el rango 30 al 40
    default:
        print("\(i) impar!!!")          //el número asignado es impar
    
    }
}



    



